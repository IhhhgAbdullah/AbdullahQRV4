import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:image/image.dart' as img;
import 'package:image_picker/image_picker.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

const int maxImages = 10;

void main() => runApp(const QrPixApp());

class QrPixApp extends StatelessWidget {
  const QrPixApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QR PiX',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF1E88E5),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _serverCtrl = TextEditingController();
  final _keyCtrl = TextEditingController();
  final _geminiCtrl = TextEditingController();
  final _picker = ImagePicker();

  final List<Uint8List> _images = [];
  String? _qrData;
  String _status = 'اختر حتى 10 صور';
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _serverCtrl.dispose();
    _keyCtrl.dispose();
    _geminiCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    _serverCtrl.text = p.getString('server') ?? '';
    _keyCtrl.text = p.getString('upkey') ?? '';
    _geminiCtrl.text = p.getString('gemini') ?? '';
  }

  Future<void> _saveSettings() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('server', _serverCtrl.text.trim());
    await p.setString('upkey', _keyCtrl.text.trim());
    await p.setString('gemini', _geminiCtrl.text.trim());
    _say('تم حفظ الإعدادات');
  }

  void _say(String s) {
    if (mounted) setState(() => _status = s);
  }

  // Pick many photos at once (up to 10 in total)
  Future<void> _pickMany() async {
    final files = await _picker.pickMultiImage(imageQuality: 100);
    if (files.isEmpty) return;
    final room = maxImages - _images.length;
    if (room <= 0) {
      _say('وصلت للحد الأقصى ($maxImages صور)');
      return;
    }
    final take = files.take(room).toList();
    for (final f in take) {
      _images.add(await f.readAsBytes());
    }
    setState(() {
      _qrData = null;
      _status = 'عدد الصور: ${_images.length} من $maxImages';
    });
  }

  Future<void> _pickCamera() async {
    if (_images.length >= maxImages) {
      _say('وصلت للحد الأقصى ($maxImages صور)');
      return;
    }
    final f = await _picker.pickImage(source: ImageSource.camera, imageQuality: 100);
    if (f == null) return;
    _images.add(await f.readAsBytes());
    setState(() {
      _qrData = null;
      _status = 'عدد الصور: ${_images.length} من $maxImages';
    });
  }

  void _clear() {
    setState(() {
      _images.clear();
      _qrData = null;
      _status = 'اختر حتى 10 صور';
    });
  }

  // Optional: Gemini finds the document area. Returns [x, y, w, h] or null.
  Future<List<double>?> _askAiCrop(Uint8List bytes) async {
    final key = _geminiCtrl.text.trim();
    if (key.isEmpty) return null;

    final small = _shrink(bytes, 1024);
    final body = {
      'contents': [
        {
          'parts': [
            {
              'text': 'Find the main document or object in this photo. '
                  'Return ONLY JSON like {"x":0.1,"y":0.1,"w":0.8,"h":0.8} '
                  'with normalized values 0 to 1 (x,y = top-left corner, w,h = width and height).'
            },
            {
              'inline_data': {'mime_type': 'image/jpeg', 'data': base64Encode(small)}
            }
          ]
        }
      ],
      'generationConfig': {'responseMimeType': 'application/json', 'temperature': 0},
    };

    final res = await http.post(
      Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent'),
      headers: {'Content-Type': 'application/json', 'x-goog-api-key': key},
      body: jsonEncode(body),
    );
    if (res.statusCode != 200) return null;

    final data = jsonDecode(res.body);
    final text = data['candidates'][0]['content']['parts'][0]['text'] as String;
    final m = jsonDecode(text.substring(text.indexOf('{'), text.lastIndexOf('}') + 1));

    double v(String k) => (m[k] as num).toDouble().clamp(0.0, 1.0);
    final x = v('x');
    final y = v('y');
    var w = v('w');
    var h = v('h');
    if (x + w > 1) w = 1 - x;
    if (y + h > 1) h = 1 - y;
    if (w < 0.2 || h < 0.2) return null;
    return [x, y, w, h];
  }

  Uint8List _shrink(Uint8List bytes, int maxSide) {
    final im = img.decodeImage(bytes);
    if (im == null) return bytes;
    final big = im.width >= im.height ? im.width : im.height;
    if (big <= maxSide) return Uint8List.fromList(img.encodeJpg(im, quality: 90));
    final r = im.width >= im.height
        ? img.copyResize(im, width: maxSide)
        : img.copyResize(im, height: maxSide);
    return Uint8List.fromList(img.encodeJpg(r, quality: 90));
  }

  // Full-resolution crop + auto levels
  Uint8List _cropAndEnhance(Uint8List bytes, List<double>? box) {
    var im = img.decodeImage(bytes);
    if (im == null) return bytes;
    if (box != null) {
      final x = (box[0] * im.width).round();
      final y = (box[1] * im.height).round();
      final w = (box[2] * im.width).round();
      final h = (box[3] * im.height).round();
      im = img.copyCrop(im, x: x, y: y, width: w, height: h);
    }
    im = img.normalize(im, min: 0, max: 255);
    return Uint8List.fromList(img.encodeJpg(im, quality: 92));
  }

  String _serverBase() => _serverCtrl.text.trim().replaceAll(RegExp(r'/$'), '');

  Future<String> _uploadOne(Uint8List bytes) async {
    final req = http.MultipartRequest('POST', Uri.parse('${_serverBase()}/upload'))
      ..headers['X-Upload-Key'] = _keyCtrl.text.trim()
      ..files.add(http.MultipartFile.fromBytes(
        'file',
        bytes,
        filename: 'qrpix.jpg',
        contentType: MediaType('image', 'jpeg'),
      ));

    final streamed = await req.send();
    final body = await streamed.stream.bytesToString();
    final j = jsonDecode(body) as Map<String, dynamic>;
    if (streamed.statusCode != 200 || j['url'] == null) {
      throw Exception(j['error'] ?? 'HTTP ${streamed.statusCode}');
    }
    return j['url'] as String;
  }

  Future<String> _createAlbum(List<String> urls) async {
    final res = await http.post(
      Uri.parse('${_serverBase()}/album'),
      headers: {
        'Content-Type': 'application/json',
        'X-Upload-Key': _keyCtrl.text.trim(),
      },
      body: jsonEncode({'urls': urls}),
    );
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    if (res.statusCode != 200 || j['url'] == null) {
      throw Exception(j['error'] ?? 'HTTP ${res.statusCode}');
    }
    return j['url'] as String;
  }

  Future<void> _generate() async {
    if (_images.isEmpty) return;
    if (_serverBase().isEmpty || _keyCtrl.text.trim().isEmpty) {
      _say('أدخل رابط السيرفر ومفتاح الرفع أولًا');
      return;
    }

    setState(() => _busy = true);
    try {
      final urls = <String>[];
      for (var i = 0; i < _images.length; i++) {
        _say('معالجة ورفع ${i + 1} من ${_images.length}...');
        final bytes = _images[i];
        List<double>? box;
        try {
          box = await _askAiCrop(bytes);
        } catch (_) {
          box = null;
        }
        final out = _cropAndEnhance(bytes, box);
        urls.add(await _uploadOne(out));
      }

      _say('إنشاء الألبوم...');
      final albumUrl = await _createAlbum(urls);
      if (mounted) {
        setState(() {
          _qrData = albumUrl;
          _status = 'تم. الماسح يفتح ألبوم ${urls.length} صور';
        });
      }
    } catch (e) {
      _say('خطأ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _card(String title, Widget child) {
    return Card(
      color: const Color(0xCC0B1D3A),
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 18, color: Color(0xFFF1D77A), fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            child,
          ],
        ),
      ),
    );
  }

  Widget _field(TextEditingController c, String label, {bool obscure = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: c,
        obscureText: obscure,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: Image.asset('assets/bg.png', fit: BoxFit.cover)),
          Positioned.fill(child: Container(color: Colors.black.withOpacity(0.55))),
          SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Center(
                  child: Text('QR PiX',
                      style: TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF64B5F6))),
                ),
                const SizedBox(height: 16),
                _card(
                  '1. الصور (حتى $maxImages)',
                  Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: _busy ? null : _pickMany,
                              icon: const Icon(Icons.photo_library),
                              label: const Text('اختيار صور'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: _busy ? null : _pickCamera,
                              icon: const Icon(Icons.camera_alt),
                              label: const Text('كاميرا'),
                            ),
                          ),
                        ],
                      ),
                      if (_images.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            for (final b in _images)
                              ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.memory(b, width: 70, height: 70, fit: BoxFit.cover),
                              ),
                          ],
                        ),
                        TextButton(onPressed: _busy ? null : _clear, child: const Text('مسح الكل')),
                      ],
                    ],
                  ),
                ),
                _card(
                  '2. الإعدادات',
                  Column(
                    children: [
                      _field(_serverCtrl, 'رابط السيرفر'),
                      _field(_keyCtrl, 'مفتاح الرفع', obscure: true),
                      _field(_geminiCtrl, 'مفتاح Gemini (اختياري)', obscure: true),
                      OutlinedButton(onPressed: _saveSettings, child: const Text('حفظ الإعدادات')),
                    ],
                  ),
                ),
                _card(
                  '3. الـQR',
                  Column(
                    children: [
                      FilledButton(
                        onPressed: _busy ? null : _generate,
                        child: Text(_busy ? 'جاري العمل...' : 'توليد QR'),
                      ),
                      const SizedBox(height: 10),
                      Text(_status, textAlign: TextAlign.center),
                      if (_qrData != null) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.all(12),
                          color: Colors.white,
                          child: QrImageView(data: _qrData!, size: 260),
                        ),
                        const SizedBox(height: 8),
                        SelectableText(_qrData!, style: const TextStyle(fontSize: 12)),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
